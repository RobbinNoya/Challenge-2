# Challenge-2

Ik wist niet zeker of een animatie verplicht was, daarom heb ik er voor de zekerheid 1 geplaatst in mijn iPad @media (min-height: 454px) and (min-width: 376px) and (max-width: 1024px)
